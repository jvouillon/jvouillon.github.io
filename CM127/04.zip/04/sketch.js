var rayon, segments;
var posx, posy;

function setup() {
  createCanvas(windowWidth, windowHeight);
  posx = windowWidth / 2;
  posy = windowHeight / 2;
  fill(255,0,0);
  strokeWeight(3);
}

function draw() {
  background(255);
  rayon = map(mouseY, 0, windowHeight, 30, 200);
  segments = floor(map(mouseX, 0, windowWidth, 3, 30));
  angle = TWO_PI / segments;
  beginShape();
  for (var i = 0; i < segments; i++) {
    vertex(posx + rayon * cos(i * angle), posy + rayon * sin(i * angle));
  }
  endShape(CLOSE);
}